# SG-XXXX - Titulo del error

## Significado

Descripcion breve de que representa este error.

## Causas comunes

- Causa 1
- Causa 2

## Accion recomendada

1. Paso 1
2. Paso 2
3. Paso 3
