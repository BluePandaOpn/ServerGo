# Error Codes

Este archivo es un indice rapido.

Documentacion detallada por error:

- `docs/errors/SG-0001.md`
- `docs/errors/SG-0002.md`
- `docs/errors/SG-0003.md`
- `docs/errors/SG-0004.md`
- `docs/errors/SG-0005.md`
- `docs/errors/SG-9999.md`

Mapa central de rutas:

- `docs/ERROR_MAP.md`

