# Error Map

Mapa central de errores de ServerGo.

Repositorio:

- https://github.com/BluePandaOpn/ServerGo

## Rutas locales

- `docs/errors/SG-0001.md`
- `docs/errors/SG-0002.md`
- `docs/errors/SG-0003.md`
- `docs/errors/SG-0004.md`
- `docs/errors/SG-0005.md`
- `docs/errors/SG-9999.md`

## Rutas web directas

- https://github.com/BluePandaOpn/ServerGo/blob/main/docs/errors/SG-0001.md
- https://github.com/BluePandaOpn/ServerGo/blob/main/docs/errors/SG-0002.md
- https://github.com/BluePandaOpn/ServerGo/blob/main/docs/errors/SG-0003.md
- https://github.com/BluePandaOpn/ServerGo/blob/main/docs/errors/SG-0004.md
- https://github.com/BluePandaOpn/ServerGo/blob/main/docs/errors/SG-0005.md
- https://github.com/BluePandaOpn/ServerGo/blob/main/docs/errors/SG-9999.md
