# Code of Conduct

## Nuestro compromiso

Queremos una comunidad abierta, respetuosa y segura para todas las personas.

## Conducta esperada

- Respeto en discusiones tecnicas.
- Criticas centradas en codigo, no en personas.
- Colaboracion constructiva y transparente.

## Conducta no aceptada

- Acoso, insultos o lenguaje discriminatorio.
- Publicacion de informacion privada sin permiso.
- Cualquier comportamiento que dañe a la comunidad.

## Aplicacion

Los mantenedores pueden moderar, editar o retirar contenido y contribuciones que incumplan este codigo.
