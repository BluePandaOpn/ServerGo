# Instalacion

## Requisitos

- Python 3.10+
- Node.js 18+
- Git (recomendado para actualizaciones)

## Pasos

1. Ejecuta `scripts/install.bat`
2. Ejecuta `run.bat`
3. Usa el menu principal

## HTTPS rapido

- `scripts/https-setup.bat`
- luego inicia servidor desde menu o `run.bat start-server`

