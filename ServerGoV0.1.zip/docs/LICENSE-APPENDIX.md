# Apendice de Licencia

Este documento complementa la licencia principal del repositorio.

## Dependencias de terceros

ServerGo utiliza librerias de terceros (Python/Node) sujetas a sus propias licencias.
Antes de distribuir una build, revisa las licencias de:

- dependencias en `node/package.json`
- dependencias Python usadas por proyectos generados

## Uso interno y externo

- Uso interno: permitido segun licencia del repositorio.
- Distribucion externa: validar cumplimiento de licencias de terceros.

## Descargo

ServerGo se entrega "tal cual", sin garantia explicita de disponibilidad,
seguridad o adecuacion para un caso particular.

